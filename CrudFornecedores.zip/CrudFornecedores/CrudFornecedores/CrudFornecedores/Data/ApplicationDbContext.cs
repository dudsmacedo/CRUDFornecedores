﻿using Microsoft.EntityFrameworkCore;
using CrudFornecedores.Models;

namespace CrudFornecedores.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        // Define o DbSet para Fornecedores, que representa a tabela no banco de dados
        public DbSet<Fornecedor> Fornecedores { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configurações adicionais de mapeamento podem ser feitas aqui se necessário
        }
    }
}
