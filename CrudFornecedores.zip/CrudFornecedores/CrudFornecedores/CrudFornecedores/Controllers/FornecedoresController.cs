﻿using CrudFornecedores.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Linq;
using CrudFornecedores.Data;

namespace CrudFornecedores.Controllers
{
    public class FornecedoresController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FornecedoresController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Fornecedores
        public async Task<IActionResult> Index()
        {
            var fornecedores = await _context.Fornecedores.ToListAsync();
            return View(fornecedores);
        }

        [HttpGet]
        public async Task<IActionResult> DetalhesJson(int id)
        {
            var fornecedor = await _context.Fornecedores
                .FirstOrDefaultAsync(m => m.Id == id);

            if (fornecedor == null)
            {
                return NotFound();
            }

            return Json(new
            {
                razaoSocial = fornecedor.RazaoSocial,
                nomeFantasia = fornecedor.NomeFantasia,
                email = fornecedor.Email,
                telefone = fornecedor.Telefone,
                nomePessoaContato = fornecedor.NomePessoaContato
            });
        }

        // GET: Fornecedores/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Fornecedores/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,RazaoSocial,NomeFantasia,Email,Telefone,NomePessoaContato,TipoLogradouro,NomeLogradouro,Numero,Complemento,Bairro,CEP,Cidade,Estado")] Fornecedor fornecedor)
        {
            if (ModelState.IsValid)
            {
                _context.Add(fornecedor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(fornecedor);
        }

        // GET: Fornecedores/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fornecedor = await _context.Fornecedores.FindAsync(id);
            if (fornecedor == null)
            {
                return NotFound();
            }
            return View(fornecedor);
        }

        // POST: Fornecedores/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,RazaoSocial,NomeFantasia,Email,Telefone,NomePessoaContato,TipoLogradouro,NomeLogradouro,Numero,Complemento,Bairro,CEP,Cidade,Estado")] Fornecedor fornecedor)
        {
            if (id != fornecedor.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(fornecedor);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FornecedorExists(fornecedor.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }
            return View(fornecedor);
        }

        // GET: Fornecedores/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fornecedor = await _context.Fornecedores
                .FirstOrDefaultAsync(m => m.Id == id);
            if (fornecedor == null)
            {
                return NotFound();
            }

            return View(fornecedor);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(int id)
        {
            try
            {
                var fornecedor = _context.Fornecedores.Find(id);
                if (fornecedor == null)
                {
                    return NotFound();
                }

                _context.Fornecedores.Remove(fornecedor);
                _context.SaveChanges();

                return Ok(new { success = true, message = "Fornecedor excluído com sucesso." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = "Erro ao excluir o fornecedor." });
            }
        }


        // Verificar se o fornecedor existe
        private bool FornecedorExists(int id)
        {
            return _context.Fornecedores.Any(e => e.Id == id);
        }
    }
}
