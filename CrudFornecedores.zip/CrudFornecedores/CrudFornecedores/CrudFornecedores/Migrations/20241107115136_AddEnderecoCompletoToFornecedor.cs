﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CrudFornecedores.Migrations
{
    /// <inheritdoc />
    public partial class AddEnderecoCompletoToFornecedor : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Renomeia coluna existente
            migrationBuilder.RenameColumn(
                name: "EnderecoCompleto",
                table: "Fornecedores",
                newName: "TipoLogradouro");

            // Adiciona novas colunas
            migrationBuilder.AddColumn<string>(
                name: "Bairro",
                table: "Fornecedores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "CEP",
                table: "Fornecedores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Cidade",
                table: "Fornecedores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Complemento",
                table: "Fornecedores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Estado",
                table: "Fornecedores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Logradouro",
                table: "Fornecedores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Numero",
                table: "Fornecedores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Remove as colunas adicionadas
            migrationBuilder.DropColumn(name: "Bairro", table: "Fornecedores");
            migrationBuilder.DropColumn(name: "CEP", table: "Fornecedores");
            migrationBuilder.DropColumn(name: "Cidade", table: "Fornecedores");
            migrationBuilder.DropColumn(name: "Complemento", table: "Fornecedores");
            migrationBuilder.DropColumn(name: "Estado", table: "Fornecedores");
            migrationBuilder.DropColumn(name: "NomeLogradouro", table: "Fornecedores");
            migrationBuilder.DropColumn(name: "Numero", table: "Fornecedores");

            // Renomeia a coluna de volta para o nome original
            migrationBuilder.RenameColumn(
                name: "TipoLogradouro",
                table: "Fornecedores",
                newName: "EnderecoCompleto");
        }
    }
}
